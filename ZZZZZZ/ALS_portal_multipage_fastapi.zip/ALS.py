
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from typing import List, Optional
import os

app = FastAPI(title="ALS Backend (FastAPI)")

# Mount /static to serve CSS/JS/HTML/Reports files
# Assumes this ALS.py sits at project root alongside HTML/, CSS/, JS/, reports/
app.mount("/static", StaticFiles(directory="."), name="static")

# CORS so the frontend (same host) can call the API in dev
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost", "http://127.0.0.1", "http://localhost:5000", "http://127.0.0.1:5000", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ------- HTML Routes (Multi-page) -------
@app.get("/", response_class=FileResponse)
async def root():
    return FileResponse("HTML/ins_dashboard.html")

@app.get("/ins_dashboard", response_class=FileResponse)
async def ins_dashboard():
    return FileResponse("HTML/ins_dashboard.html")

@app.get("/ins_mapping", response_class=FileResponse)
async def ins_mapping():
    return FileResponse("HTML/ins_mapping.html")

@app.get("/ins_learners", response_class=FileResponse)
async def ins_learners():
    return FileResponse("HTML/ins_learners.html")

@app.get("/ins_analytics", response_class=FileResponse)
async def ins_analytics():
    return FileResponse("HTML/ins_analytics.html")

@app.get("/ins_reports", response_class=FileResponse)
async def ins_reports():
    return FileResponse("HTML/ins_reports.html")

# ------- API Models & In-Memory Store -------
class Learner(BaseModel):
    id: Optional[int] = None
    name: str
    status: str
    barangay: str
    address: Optional[str] = None
    lastContact: Optional[str] = None
    progress: Optional[int] = 0
    lat: Optional[float] = None
    lng: Optional[float] = None

# Sample data (mirrors the frontend demo data)
learners_db: List[Learner] = [
    Learner(id=1, name="Juan Dela Cruz", status="graduate", barangay="Poblacion",
            lat=14.2843, lng=121.4158, lastContact="2024-08-15", progress=100),
    Learner(id=2, name="Maria Santos", status="current", barangay="San Jose",
            lat=14.2893, lng=121.4208, lastContact="2024-08-28", progress=65),
    Learner(id=3, name="Pedro Rodriguez", status="at-risk", barangay="Bagumbayan",
            lat=14.2793, lng=121.4108, lastContact="2024-07-20", progress=30),
    Learner(id=4, name="Ana Reyes", status="not-enrolled", barangay="Jasaan",
            lat=14.2943, lng=121.4258, lastContact="2024-08-01", progress=0),
    Learner(id=5, name="Carlos Mendoza", status="current", barangay="Pagsawitan",
            lat=14.2743, lng=121.4058, lastContact="2024-08-25", progress=80),
]

# ------- API Endpoints -------
@app.get("/api/learners")
async def get_learners():
    return [l.dict() for l in learners_db]

@app.post("/api/learners")
async def add_learner(learner: Learner):
    new_id = max([l.id for l in learners_db] + [0]) + 1
    learner.id = new_id
    learners_db.append(learner)
    return {"success": True, "message": "Learner added successfully", "id": new_id}

@app.post("/api/reports")
async def generate_report(payload: dict):
    # A stub that pretends to generate a report and returns a downloadable path
    report_url = "/static/reports/sample.pdf"
    return {"success": True, "reportUrl": report_url}

# Helpful for local dev: `uvicorn ALS:app --reload --port 5000`
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ALS:app", host="0.0.0.0", port=5000, reload=True)
